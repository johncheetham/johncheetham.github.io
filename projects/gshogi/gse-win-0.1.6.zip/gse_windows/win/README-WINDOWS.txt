This folder contains a windows executable built on cygwin on
windows XP 32 bit.


Acknowledgements
----------------
The cygwin build requires cygwin1.dll which is licensed under the GPL.
Source code to build this dll is available at http://cygwin.com/cvs.html.


