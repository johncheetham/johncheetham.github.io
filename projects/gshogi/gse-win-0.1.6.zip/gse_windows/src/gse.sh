#!/bin/sh

#
# Run the gse USI engine
#

BASEDIR=`dirname $0`
cd $BASEDIR

./gse

